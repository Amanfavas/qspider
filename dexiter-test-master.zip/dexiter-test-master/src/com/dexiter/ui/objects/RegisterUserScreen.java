package com.dexiter.ui.objects;

import org.openqa.selenium.WebElement;

import io.appium.java_client.AppiumDriver;

public class RegisterUserScreen 
{
	AppiumDriver driver;
	String instance_info;
	public RegisterUserScreen(AppiumDriver driver)
	{
		this.driver = driver;
		instance_info = this.driver.getClass().getName();
	}
	public WebElement getSignUpButton()
	{
		if(instance_info.contains("AndroidDriver"))
		{
			return driver.findElementById("com.flipkart.android:id/btn_msignup");
		}
		else
		{
			return driver.findElementByXPath("//Define XPath");
		}
	}
	public WebElement getExistingUserButton()
	{
		if(instance_info.contains("AndroidDriver"))
		{
			return driver.findElementById("com.flipkart.android:id/btn_mlogin");
		}
		else
		{
			return driver.findElementByAccessibilityId("Define Acc ID");
		}
	}
	public WebElement getCaptionText()
	{
		if(instance_info.contains("AndroidDriver"))
		{
			return driver.findElementById("com.flipkart.android:id/banner_text");
		}
		else
		{
			return driver.findElementByAccessibilityId("Define Acc ID");
		}
	}
	public WebElement getPhoneNumberTextbox()
	{
		if(instance_info.contains("AndroidDriver"))
		{
			return driver.findElementById("com.flipkart.android:id/mobileNo");
		}
		else
		{
			return driver.findElementByAccessibilityId("Define Acc ID");
		}
	}
}
