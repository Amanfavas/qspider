package com.dexiter.project.utils;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;

import com.dexiter.generic.utils.DataHandlers;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;

public class CreateDriver 
{
	public static AppiumDriver getDriverInstance()
	{
		URL ip = null;
		AppiumDriver driver=null;
		try {
			ip = new URL("http://127.0.0.1:4723/wd/hub");
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		
		String env = DataHandlers.
				getDataFromProperties("./config-test/testconfig.properties", "platform");
		String device_id = DataHandlers.
				getDataFromProperties("./config-test/testconfig.properties", "device_id");
		String platformName = DataHandlers.
			getDataFromProperties("./device-"+env+"-info/"+device_id+".properties", "platformName");
		String platformVersion = DataHandlers.
		getDataFromProperties("./device-"+env+"-info/"+device_id+".properties", "platformVersion");
		String deviceName = DataHandlers.
		getDataFromProperties("./device-"+env+"-info/"+device_id+".properties", "deviceName");
		DesiredCapabilities cap = new DesiredCapabilities();
		cap.setCapability("platformName", platformName);
		cap.setCapability("platformVersion", platformVersion);
		cap.setCapability("deviceName", deviceName);
		String appPackage = "";
		String appActivity = "";
		String deviceUDID = "";
		String bundleID = "";
		if(env.equals("aos"))
		{
			appPackage = DataHandlers.
			getDataFromProperties("./device-"+env+"-info/"+device_id+".properties", "appPackage");
			appActivity = DataHandlers.
			getDataFromProperties("./device-"+env+"-info/"+device_id+".properties", "appActivity");
			cap.setCapability("appPackage", appPackage);
			cap.setCapability("appActivity", appActivity);
			driver = new AndroidDriver(ip, cap);
		}
		else
		{
			deviceUDID = DataHandlers.
			getDataFromProperties("./device-"+env+"-info/"+device_id+".properties", "deviceUDID");
			bundleID = DataHandlers.
			getDataFromProperties("./device-"+env+"-info/"+device_id+".properties", "bundleID");
			cap.setCapability("deviceUDID", deviceUDID);
			cap.setCapability("bundleID", bundleID);
			driver = new IOSDriver(ip, cap);
		}
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		return driver;
	}
}
