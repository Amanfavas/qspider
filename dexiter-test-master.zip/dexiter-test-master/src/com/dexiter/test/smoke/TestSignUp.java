package com.dexiter.test.smoke;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.dexiter.project.utils.CreateDriver;
import com.dexiter.ui.objects.RegisterUserScreen;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;

public class TestSignUp 
{
	AppiumDriver driver;
	RegisterUserScreen register_user;
	
	@BeforeMethod
	public void preCondition() throws MalformedURLException
	{
		driver = CreateDriver.getDriverInstance();
		register_user = new RegisterUserScreen(driver);
	}
	@Test
	public void testFlipkartRegisterScreen()
	{
		String actual_text = 
				register_user.getCaptionText().getAttribute("text");
		String expected_text = "Your number is safe with us";
		Assert.assertEquals(actual_text, expected_text);
		
		register_user.getPhoneNumberTextbox().sendKeys("85895588858585");
		register_user.getSignUpButton().click();
	}
	
	

}
